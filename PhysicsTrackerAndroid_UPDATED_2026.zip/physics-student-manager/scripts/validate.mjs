import fs from 'node:fs';
import vm from 'node:vm';

const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const inlineScripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)]
  .map(match => match[1].trim()).filter(Boolean);
if (inlineScripts.length !== 1) throw new Error(`Expected one inline application script, found ${inlineScripts.length}`);
new vm.Script(inlineScripts[0], { filename: 'index.html:inline-script' });

const worker = fs.readFileSync(new URL('../sw.js', import.meta.url), 'utf8');
new vm.Script(worker, { filename: 'sw.js' });

const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.webmanifest', import.meta.url), 'utf8'));
if (!manifest.name || !manifest.start_url || !Array.isArray(manifest.icons) || manifest.icons.length === 0) {
  throw new Error('PWA manifest is missing required fields');
}
for (const icon of manifest.icons) {
  const iconPath = new URL(`../${icon.src.replace(/^\.\//, '')}`, import.meta.url);
  if (!fs.existsSync(iconPath)) throw new Error(`Missing PWA icon: ${icon.src}`);
}

for (const required of ['groups', 'students', 'attendance', 'payments']) {
  if (!html.includes(`'${required}'`)) throw new Error(`Expected application data section: ${required}`);
}
console.log('Validation passed: application JavaScript, service worker, manifest, and icon paths.');
